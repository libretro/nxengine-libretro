
#ifndef _BALROG_COMMON_H
#define _BALROG_COMMON_H

void balrog_grab_player(Object *o);
bool balrog_toss_player_away(Object *o);


#endif
