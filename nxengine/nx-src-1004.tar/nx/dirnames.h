

extern const char *data_dir;
extern const char *stage_dir;
extern const char *pic_dir;
extern const char *savegamename;
extern const char *nxdata_dir;
