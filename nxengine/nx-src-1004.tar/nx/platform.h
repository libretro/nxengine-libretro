
#ifndef _PLATFORM_H
#define _PLATFORM_H

extern "C"
{
	void platform_sync_to_vblank(void);
};



#endif
